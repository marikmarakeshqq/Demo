USE [Exam];
GO

CREATE TABLE dbo.[Пользователи]
(
    [КодПользователя] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Логин] NVARCHAR(100) NOT NULL,
    [ХэшПароля] NVARCHAR(256) NOT NULL,
    [Роль] NVARCHAR(50) NOT NULL,
    [Заблокирован] BIT NOT NULL CONSTRAINT [DF_Пользователи_Заблокирован] DEFAULT (0),
    [ПопыткиВхода] INT NOT NULL CONSTRAINT [DF_Пользователи_ПопыткиВхода] DEFAULT (0),
    [ПервыйВход] BIT NOT NULL CONSTRAINT [DF_Пользователи_ПервыйВход] DEFAULT (1),
    CONSTRAINT [UQ_Пользователи_Логин] UNIQUE ([Логин]),
    CONSTRAINT [CK_Пользователи_Роль] CHECK ([Роль] IN (N'Администратор', N'Пользователь')),
    CONSTRAINT [CK_Пользователи_ПопыткиВхода] CHECK ([ПопыткиВхода] >= 0)
);
GO
