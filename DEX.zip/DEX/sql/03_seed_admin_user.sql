USE [Exam];
GO

INSERT INTO dbo.[Пользователи]
(
    [Логин],
    [ХэшПароля],
    [Роль],
    [Заблокирован],
    [ПопыткиВхода],
    [ПервыйВход]
)
VALUES
(
    N'admin',
    N'PBKDF2-SHA256$100000$nSLlmd8lSBboFjRMPgfrAQ==$lPLokRpfB+JYMo9TstGc3zJKvZg323/MSLlbU3nzHTc=',
    N'Администратор',
    0,
    0,
    1
);
GO
