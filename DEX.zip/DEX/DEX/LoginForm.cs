using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using DEX.Services;

namespace DEX.Forms
{
    public partial class LoginForm : Form
    {
        private readonly AuthService authService;
        private PictureBox[] puzzlePieces;
        private readonly int[] correctOrder = { 1, 2, 3, 4 };
        private int[] currentOrder = new int[4];
        private int? firstSelectedIndex;

        public LoginForm()
        {
            InitializeComponent();
            authService = new AuthService();
            InitializePuzzle();
        }

        private void InitializePuzzle()
        {
            puzzlePieces = new[] { picPiece1, picPiece2, picPiece3, picPiece4 };

            for (int i = 0; i < puzzlePieces.Length; i++)
            {
                puzzlePieces[i].Click += PuzzlePiece_Click;
                puzzlePieces[i].BorderStyle = BorderStyle.FixedSingle;
                puzzlePieces[i].SizeMode = PictureBoxSizeMode.StretchImage;
            }

            ShufflePuzzle();
        }

        private string GetImagePath(string fileName)
        {
            string[] possiblePaths =
            {
                Path.Combine(Application.StartupPath, fileName),
                Path.Combine(Application.StartupPath, "..", "..", fileName),
                Path.Combine(Application.StartupPath, "..", "..", "..", "DEX", fileName),
                fileName
            };

            foreach (string path in possiblePaths)
            {
                string fullPath = Path.GetFullPath(path);
                if (File.Exists(fullPath))
                {
                    return fullPath;
                }
            }

            return fileName;
        }

        private void ShufflePuzzle()
        {
            Random random = new Random();
            currentOrder = correctOrder.OrderBy(x => random.Next()).ToArray();

            string[] imageFiles = { "1.png", "2.png", "3.png", "4.png" };
            for (int i = 0; i < puzzlePieces.Length; i++)
            {
                int imageIndex = currentOrder[i] - 1;
                string imagePath = GetImagePath(imageFiles[imageIndex]);

                if (!File.Exists(imagePath))
                {
                    continue;
                }

                if (puzzlePieces[i].Image != null)
                {
                    puzzlePieces[i].Image.Dispose();
                    puzzlePieces[i].Image = null;
                }

                puzzlePieces[i].Image = Image.FromFile(imagePath);
            }

            firstSelectedIndex = null;
            ResetPuzzleSelection();
        }

        private void PuzzlePiece_Click(object sender, EventArgs e)
        {
            PictureBox clickedPiece = sender as PictureBox;
            int clickedIndex = Array.IndexOf(puzzlePieces, clickedPiece);

            if (firstSelectedIndex == null)
            {
                firstSelectedIndex = clickedIndex;
                puzzlePieces[clickedIndex].BackColor = Color.Yellow;
                return;
            }

            if (firstSelectedIndex.Value != clickedIndex)
            {
                SwapPieces(firstSelectedIndex.Value, clickedIndex);
            }

            ResetPuzzleSelection();
            firstSelectedIndex = null;
        }

        private void SwapPieces(int index1, int index2)
        {
            int temp = currentOrder[index1];
            currentOrder[index1] = currentOrder[index2];
            currentOrder[index2] = temp;

            Image tempImage = puzzlePieces[index1].Image;
            puzzlePieces[index1].Image = puzzlePieces[index2].Image;
            puzzlePieces[index2].Image = tempImage;
        }

        private void ResetPuzzleSelection()
        {
            foreach (PictureBox piece in puzzlePieces)
            {
                piece.BackColor = SystemColors.Control;
            }
        }

        private bool IsPuzzleCorrect()
        {
            return currentOrder.SequenceEqual(correctOrder);
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text))
            {
                MessageBox.Show("Пожалуйста, введите логин.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Пожалуйста, введите пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            if (authService.IsUserBlocked(login))
            {
                MessageBox.Show("Вы заблокированы. Обратитесь к администратору.", "Доступ запрещен", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (!IsPuzzleCorrect())
            {
                MessageBox.Show("Пазл собран неверно. Попробуйте еще раз.", "Ошибка капчи", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                authService.IncrementFailedAttempts(login);
                ShufflePuzzle();
                return;
            }

            if (!authService.ValidateCredentials(login, password))
            {
                MessageBox.Show("Вы ввели неверный логин или пароль. Проверьте данные и попробуйте снова.", "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                authService.IncrementFailedAttempts(login);
                ShufflePuzzle();
                return;
            }

            authService.ResetFailedAttempts(login);
            MessageBox.Show("Вы успешно авторизовались.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RedirectUserBasedOnRole(login);
        }

        private void RedirectUserBasedOnRole(string login)
        {
            string role = authService.GetUserRole(login);
            Form nextForm;

            switch (role)
            {
                case "Администратор":
                    nextForm = new AdminForm();
                    break;
                case "Пользователь":
                    nextForm = new UserForm();
                    break;
                default:
                    MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
            }

            nextForm.FormClosed += (sender, args) => Close();
            nextForm.Show();
            Hide();
        }
    }
}
