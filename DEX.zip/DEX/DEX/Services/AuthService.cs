using System;
using System.Data;
using System.Data.SqlClient;

namespace DEX.Services
{
    public class AuthService
    {
        private readonly DatabaseService databaseService;
        private readonly PasswordHashService passwordHashService;

        public AuthService()
        {
            databaseService = new DatabaseService();
            passwordHashService = new PasswordHashService();
        }

        public bool IsUserBlocked(string login)
        {
            const string query = "SELECT [Заблокирован] FROM [Пользователи] WHERE [Логин] = @Login";
            SqlParameter[] parameters =
            {
                new SqlParameter("@Login", login)
            };

            DataTable result = databaseService.GetDataTable(query, parameters);
            return result.Rows.Count > 0 && Convert.ToBoolean(result.Rows[0]["Заблокирован"]);
        }

        public bool ValidateCredentials(string login, string password)
        {
            const string query = "SELECT [ХэшПароля] FROM [Пользователи] WHERE [Логин] = @Login";
            SqlParameter[] parameters =
            {
                new SqlParameter("@Login", login)
            };

            DataTable result = databaseService.GetDataTable(query, parameters);
            if (result.Rows.Count == 0)
            {
                return false;
            }

            string passwordHash = result.Rows[0]["ХэшПароля"].ToString();
            return passwordHashService.VerifyPassword(password, passwordHash);
        }

        public void IncrementFailedAttempts(string login)
        {
            const string selectQuery = "SELECT [ПопыткиВхода] FROM [Пользователи] WHERE [Логин] = @Login";
            SqlParameter[] selectParams =
            {
                new SqlParameter("@Login", login)
            };

            DataTable result = databaseService.GetDataTable(selectQuery, selectParams);
            if (result.Rows.Count == 0)
            {
                return;
            }

            int currentAttempts = Convert.ToInt32(result.Rows[0]["ПопыткиВхода"]);
            int newAttempts = currentAttempts + 1;

            const string updateQuery = "UPDATE [Пользователи] SET [ПопыткиВхода] = @Attempts WHERE [Логин] = @Login";
            SqlParameter[] updateParams =
            {
                new SqlParameter("@Attempts", newAttempts),
                new SqlParameter("@Login", login)
            };
            databaseService.ExecuteNonQuery(updateQuery, updateParams);

            if (newAttempts < 3)
            {
                return;
            }

            const string blockQuery = "UPDATE [Пользователи] SET [Заблокирован] = 1 WHERE [Логин] = @Login";
            SqlParameter[] blockParams =
            {
                new SqlParameter("@Login", login)
            };
            databaseService.ExecuteNonQuery(blockQuery, blockParams);
        }

        public void ResetFailedAttempts(string login)
        {
            const string query = "UPDATE [Пользователи] SET [ПопыткиВхода] = 0 WHERE [Логин] = @Login";
            SqlParameter[] parameters =
            {
                new SqlParameter("@Login", login)
            };

            databaseService.ExecuteNonQuery(query, parameters);
        }

        public string GetUserRole(string login)
        {
            const string query = "SELECT [Роль] FROM [Пользователи] WHERE [Логин] = @Login";
            SqlParameter[] parameters =
            {
                new SqlParameter("@Login", login)
            };

            DataTable result = databaseService.GetDataTable(query, parameters);
            return result.Rows.Count > 0
                ? result.Rows[0]["Роль"].ToString()
                : string.Empty;
        }
    }
}
