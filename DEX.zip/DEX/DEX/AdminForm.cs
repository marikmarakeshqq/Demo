using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DEX.Services;

namespace DEX.Forms
{
    public partial class AdminForm : Form
    {
        private readonly DatabaseService databaseService;

        public AdminForm()
        {
            InitializeComponent();
            databaseService = new DatabaseService();
            LoadUsers();
        }

        private void LoadUsers()
        {
            try
            {
                const string query = "SELECT [КодПользователя], [Логин], N'********' AS [Пароль], [Роль], [Заблокирован], [ПопыткиВхода] FROM [Пользователи] ORDER BY [КодПользователя]";
                DataTable dataTable = databaseService.GetDataTable(query);
                dgvUsers.DataSource = dataTable;
                dgvUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (dgvUsers.Columns.Count == 0)
                {
                    return;
                }

                dgvUsers.Columns["КодПользователя"].HeaderText = "Код";
                dgvUsers.Columns["КодПользователя"].FillWeight = 20;
                dgvUsers.Columns["Логин"].HeaderText = "Логин";
                dgvUsers.Columns["Пароль"].HeaderText = "Пароль";
                dgvUsers.Columns["Роль"].HeaderText = "Роль";
                dgvUsers.Columns["Заблокирован"].HeaderText = "Заблокирован";
                dgvUsers.Columns["ПопыткиВхода"].HeaderText = "Попытки входа";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке пользователей: {ex.Message}", "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (var userForm = new EditUserForm())
            {
                if (userForm.ShowDialog(this) == DialogResult.OK)
                {
                    LoadUsers();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для редактирования.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow selectedRow = dgvUsers.SelectedRows[0];
            int userId = Convert.ToInt32(selectedRow.Cells["КодПользователя"].Value);
            string login = selectedRow.Cells["Логин"].Value.ToString();
            string role = selectedRow.Cells["Роль"].Value.ToString();

            using (var userForm = new EditUserForm(userId, login, role))
            {
                if (userForm.ShowDialog(this) == DialogResult.OK)
                {
                    LoadUsers();
                }
            }
        }

        private void btnUnblock_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для снятия блокировки.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow selectedRow = dgvUsers.SelectedRows[0];
            int userId = Convert.ToInt32(selectedRow.Cells["КодПользователя"].Value);
            string login = selectedRow.Cells["Логин"].Value.ToString();

            DialogResult result = MessageBox.Show(
                $"Снять блокировку с пользователя '{login}'?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result != DialogResult.Yes)
            {
                return;
            }

            try
            {
                const string query = "UPDATE [Пользователи] SET [Заблокирован] = 0, [ПопыткиВхода] = 0 WHERE [КодПользователя] = @UserId";
                SqlParameter[] parameters =
                {
                    new SqlParameter("@UserId", userId)
                };

                int rowsAffected = databaseService.ExecuteNonQuery(query, parameters);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Блокировка снята успешно.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadUsers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при снятии блокировки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
