using System.Windows.Forms;

namespace DEX.Forms
{
    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();
        }
    }
}
