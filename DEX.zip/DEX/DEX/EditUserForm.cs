using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DEX.Services;

namespace DEX.Forms
{
    public partial class EditUserForm : Form
    {
        private readonly DatabaseService databaseService;
        private readonly PasswordHashService passwordHashService;
        private readonly int? userId;
        private readonly bool isEditMode;

        public EditUserForm()
        {
            InitializeComponent();
            databaseService = new DatabaseService();
            passwordHashService = new PasswordHashService();
            txtPassword.UseSystemPasswordChar = true;
            Text = "Добавление пользователя";
        }

        public EditUserForm(int userId, string login, string role) : this()
        {
            this.userId = userId;
            isEditMode = true;

            txtLogin.Text = login;
            cmbRole.Text = role;
            txtLogin.ReadOnly = true;
            lblPassword.Text = "Новый пароль:";
            Text = "Редактирование пользователя";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text))
            {
                MessageBox.Show("Введите логин.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!isEditMode && string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Введите пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(cmbRole.Text))
            {
                MessageBox.Show("Выберите роль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;
            string role = cmbRole.Text;

            try
            {
                if (userId == null)
                {
                    CreateUser(login, password, role);
                }
                else
                {
                    UpdateUser(password, role);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении пользователя: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CreateUser(string login, string password, string role)
        {
            const string checkQuery = "SELECT COUNT(*) AS [Количество] FROM [Пользователи] WHERE [Логин] = @Login";
            SqlParameter[] checkParams =
            {
                new SqlParameter("@Login", login)
            };

            DataTable checkResult = databaseService.GetDataTable(checkQuery, checkParams);
            if (checkResult.Rows.Count > 0 && Convert.ToInt32(checkResult.Rows[0]["Количество"]) > 0)
            {
                MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            const string insertQuery = "INSERT INTO [Пользователи] ([Логин], [ХэшПароля], [Роль], [Заблокирован], [ПопыткиВхода], [ПервыйВход]) VALUES (@Login, @PasswordHash, @Role, 0, 0, 1)";
            SqlParameter[] insertParams =
            {
                new SqlParameter("@Login", login),
                new SqlParameter("@PasswordHash", passwordHashService.HashPassword(password)),
                new SqlParameter("@Role", role)
            };

            int rowsAffected = databaseService.ExecuteNonQuery(insertQuery, insertParams);
            if (rowsAffected > 0)
            {
                MessageBox.Show("Пользователь успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void UpdateUser(string password, string role)
        {
            bool shouldUpdatePassword = !string.IsNullOrWhiteSpace(password);
            string updateQuery = shouldUpdatePassword
                ? "UPDATE [Пользователи] SET [ХэшПароля] = @PasswordHash, [Роль] = @Role WHERE [КодПользователя] = @UserId"
                : "UPDATE [Пользователи] SET [Роль] = @Role WHERE [КодПользователя] = @UserId";

            SqlParameter[] updateParams = shouldUpdatePassword
                ? new[]
                {
                    new SqlParameter("@PasswordHash", passwordHashService.HashPassword(password)),
                    new SqlParameter("@Role", role),
                    new SqlParameter("@UserId", userId.Value)
                }
                : new[]
                {
                    new SqlParameter("@Role", role),
                    new SqlParameter("@UserId", userId.Value)
                };

            int rowsAffected = databaseService.ExecuteNonQuery(updateQuery, updateParams);
            if (rowsAffected > 0)
            {
                MessageBox.Show("Пользователь успешно изменен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
