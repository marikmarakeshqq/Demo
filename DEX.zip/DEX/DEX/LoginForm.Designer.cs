namespace DEX.Forms
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.pnlCaptcha = new System.Windows.Forms.Panel();
            this.picPiece4 = new System.Windows.Forms.PictureBox();
            this.picPiece3 = new System.Windows.Forms.PictureBox();
            this.picPiece2 = new System.Windows.Forms.PictureBox();
            this.picPiece1 = new System.Windows.Forms.PictureBox();
            this.lblCaptchaHint = new System.Windows.Forms.Label();
            this.pnlCaptcha.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(20, 20);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(41, 13);
            this.lblLogin.TabIndex = 0;
            this.lblLogin.Text = "Логин:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(20, 60);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(48, 13);
            this.lblPassword.TabIndex = 1;
            this.lblPassword.Text = "Пароль:";
            // 
            // txtLogin
            // 
            this.txtLogin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogin.Location = new System.Drawing.Point(80, 17);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(300, 20);
            this.txtLogin.TabIndex = 2;
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassword.Location = new System.Drawing.Point(80, 57);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(300, 20);
            this.txtPassword.TabIndex = 3;
            // 
            // btnEnter
            // 
            this.btnEnter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEnter.Location = new System.Drawing.Point(305, 390);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 30);
            this.btnEnter.TabIndex = 4;
            this.btnEnter.Text = "Войти";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // pnlCaptcha
            // 
            this.pnlCaptcha.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCaptcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCaptcha.Controls.Add(this.picPiece4);
            this.pnlCaptcha.Controls.Add(this.picPiece3);
            this.pnlCaptcha.Controls.Add(this.picPiece2);
            this.pnlCaptcha.Controls.Add(this.picPiece1);
            this.pnlCaptcha.Location = new System.Drawing.Point(20, 100);
            this.pnlCaptcha.Name = "pnlCaptcha";
            this.pnlCaptcha.Size = new System.Drawing.Size(360, 280);
            this.pnlCaptcha.TabIndex = 5;
            // 
            // picPiece4
            // 
            this.picPiece4.Location = new System.Drawing.Point(180, 140);
            this.picPiece4.Name = "picPiece4";
            this.picPiece4.Size = new System.Drawing.Size(160, 120);
            this.picPiece4.TabIndex = 3;
            this.picPiece4.TabStop = false;
            // 
            // picPiece3
            // 
            this.picPiece3.Location = new System.Drawing.Point(10, 140);
            this.picPiece3.Name = "picPiece3";
            this.picPiece3.Size = new System.Drawing.Size(160, 120);
            this.picPiece3.TabIndex = 2;
            this.picPiece3.TabStop = false;
            // 
            // picPiece2
            // 
            this.picPiece2.Location = new System.Drawing.Point(180, 10);
            this.picPiece2.Name = "picPiece2";
            this.picPiece2.Size = new System.Drawing.Size(160, 120);
            this.picPiece2.TabIndex = 1;
            this.picPiece2.TabStop = false;
            // 
            // picPiece1
            // 
            this.picPiece1.Location = new System.Drawing.Point(10, 10);
            this.picPiece1.Name = "picPiece1";
            this.picPiece1.Size = new System.Drawing.Size(160, 120);
            this.picPiece1.TabIndex = 0;
            this.picPiece1.TabStop = false;
            // 
            // lblCaptchaHint
            // 
            this.lblCaptchaHint.AutoSize = true;
            this.lblCaptchaHint.Location = new System.Drawing.Point(20, 84);
            this.lblCaptchaHint.Name = "lblCaptchaHint";
            this.lblCaptchaHint.Size = new System.Drawing.Size(291, 13);
            this.lblCaptchaHint.TabIndex = 6;
            this.lblCaptchaHint.Text = "Соберите пазл: кликните на два фрагмента для обмена";
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 440);
            this.Controls.Add(this.lblCaptchaHint);
            this.Controls.Add(this.pnlCaptcha);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblLogin);
            this.MinimumSize = new System.Drawing.Size(416, 479);
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.pnlCaptcha.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picPiece4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPiece1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Panel pnlCaptcha;
        private System.Windows.Forms.PictureBox picPiece1;
        private System.Windows.Forms.PictureBox picPiece2;
        private System.Windows.Forms.PictureBox picPiece3;
        private System.Windows.Forms.PictureBox picPiece4;
        private System.Windows.Forms.Label lblCaptchaHint;
    }
}
